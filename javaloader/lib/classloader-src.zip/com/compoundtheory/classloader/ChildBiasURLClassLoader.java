package com.compoundtheory.classloader;

import java.net.URL;
import java.net.URLClassLoader;
import java.net.URLStreamHandlerFactory;


public class ChildBiasURLClassLoader extends NetworkClassLoader {

	private ClassLoader parent;
	
	public ChildBiasURLClassLoader(URL[] urls) 
	{
		super();
	}

	public ChildBiasURLClassLoader(URL[] urls, ClassLoader parent) 
	{
		super(parent);
	}
	
	private void configure(URL[] urls)
	{
		for(int counter = 0; counter < urls.length; counter++)
		{
			this.addURL(urls[counter]);
		}
	}

	/**
	 * Child biased class load function
	 */
	/*
    public final synchronized Class loadClass(String name, boolean resolve)
	throws ClassNotFoundException
    {
		// First check if we have permission to access the package. This
		// should go away once we've added support for exported packages.
		SecurityManager sm = System.getSecurityManager();
		if (sm != null) {
	            String cname = name.replace('/', '.');
	            if (cname.startsWith("[")) {
	                int b = cname.lastIndexOf('[') + 2;
	                if (b > 1 && b < cname.length()) {
	                    cname = cname.substring(b);
	                }
	            }
		    int i = cname.lastIndexOf('.');
		    if (i != -1) {
			sm.checkPackageAccess(cname.substring(0, i));
		    }
		}
	
		// First, check if the class has already been loaded
		Class c = findLoadedClass(name);
		if (c == null) {
		    try 
		    {
		    	c = findClass(name);
		    }
		    catch (ClassNotFoundException e) 
		    {
		    	c = super.loadClass(name, resolve);
		    }
		}
		if (resolve) {
		    resolveClass(c);
		}
		return c;	
    }
    */
}
