/**
 * 
 */
package com.compoundtheory.coldfusion.cfc.spring;

import com.compoundtheory.coldfusion.cfc.CFCDynamicProxy;

/**
 * Factory for creating a CFC Dynamic Proxy to pass back to Spring
 * 
 * @author Mark Mandel
 *
 */
public class ComponentProxyFactory
{
	private String path;
	private String[] interfaces;
	
	public ComponentProxyFactory(String path, String[] interfaces)
	{
		debug("Created! " + path);
		setPath(path);
		setInterfaces(interfaces);
	}
	
	public Object getProxy() throws Throwable
	{
		return CFCDynamicProxy.createInstance(getPath(), getInterfaces());
	}

	public String getPath()
	{
		return path;
	}

	private void setPath(String path)
	{
		this.path = path;
	}

	public String[] getInterfaces()
	{
		return interfaces;
	}

	private void setInterfaces(String[] interfaces)
	{
		this.interfaces = interfaces;
	}
	
	
	private void debug(String str)
	{
		System.out.println("[" + getClass().getName() + "] " + str);
	}
}
