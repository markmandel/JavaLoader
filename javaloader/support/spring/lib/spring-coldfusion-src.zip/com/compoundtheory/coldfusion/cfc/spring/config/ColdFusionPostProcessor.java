/**
 * 
 */
package com.compoundtheory.coldfusion.cfc.spring.config;

import java.util.Iterator;

import org.springframework.aop.framework.AopInfrastructureBean;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanCreationException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.beans.factory.config.InstantiationAwareBeanPostProcessorAdapter;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;

import com.compoundtheory.coldfusion.cfc.spring.ComponentProxyFactory;

/**
 * Post processor for switching out the ComponentProxyFactory for the CFC proxy it creates
 * 
 * @author Mark Mandel
 *
 */
public class ColdFusionPostProcessor extends InstantiationAwareBeanPostProcessorAdapter implements BeanFactoryAware
{
	private ConfigurableBeanFactory beanFactory;

	final DefaultListableBeanFactory scriptBeanFactory = new DefaultListableBeanFactory();	
	
	/**
	 * Constructor
	 */
	public ColdFusionPostProcessor()
	{
		super();
	}
	
	/* (non-Javadoc)
	 * @see org.springframework.beans.factory.config.InstantiationAwareBeanPostProcessorAdapter#postProcessBeforeInstantiation(java.lang.Class, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Object postProcessBeforeInstantiation(Class beanClass, String beanName) throws BeansException
	{
		debug("Post Process: " + beanClass.getName());
		
		if(!ComponentProxyFactory.class.isAssignableFrom(beanClass))
		{
			return null;
		}
		
		debug("** Found: " + beanName);
		
		ComponentProxyFactory factory = (ComponentProxyFactory)getScriptBeanFactory().getBean(beanName, ComponentProxyFactory.class);
		
		try
		{
			return factory.getProxy();
		}
		catch (Throwable e)
		{
			BeansException exc = new BeanCreationException(beanName, "Error creating CFC: " + factory.getPath(), e);
			
			throw exc;
		}
	}

	/* (non-Javadoc)
	 * @see org.springframework.beans.factory.config.InstantiationAwareBeanPostProcessorAdapter#predictBeanType(java.lang.Class, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Class predictBeanType(Class beanClass, String beanName)
	{
		//we have no idea at this point
		return null;
	}



	/** 
	 * This was lifted straight out of the Spring Scripting support.
	 * @see org.springframework.beans.factory.BeanFactoryAware#setBeanFactory(org.springframework.beans.factory.BeanFactory)
	 * @see org.springframework.scripting.support.ScriptFactoryPostProcessor#setBeanFactory(org.springframework.beans.factory.BeanFactory)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void setBeanFactory(BeanFactory beanFactory) {
		if (!(beanFactory instanceof ConfigurableBeanFactory)) {
			throw new IllegalStateException("ScriptFactoryPostProcessor doesn't work with a BeanFactory " +
					"which does not implement ConfigurableBeanFactory: " + beanFactory.getClass());
		}
		this.beanFactory = (ConfigurableBeanFactory) beanFactory;

		// Required so that references (up container hierarchies) are correctly resolved.
		this.scriptBeanFactory.setParentBeanFactory(this.beanFactory);

		// Required so that all BeanPostProcessors, Scopes, etc become available.
		this.scriptBeanFactory.copyConfigurationFrom(this.beanFactory);

		// Filter out BeanPostProcessors that are part of the AOP infrastructure,
		// since those are only meant to apply to beans defined in the original factory.
		for (Iterator<BeanPostProcessor> it = this.scriptBeanFactory.getBeanPostProcessors().iterator(); it.hasNext();) {
			BeanPostProcessor postProcessor = it.next();
			if (postProcessor instanceof AopInfrastructureBean) {
				it.remove();
			}
		}
	}

	/**
	 * @return the beanFactory
	 */
	private ConfigurableBeanFactory getBeanFactory()
	{
		return beanFactory;
	}

	/**
	 * @return the scriptBeanFactory
	 */
	private DefaultListableBeanFactory getScriptBeanFactory()
	{
		return scriptBeanFactory;
	}

	private void debug(String str)
	{
		System.out.println("[" + getClass().getName() + "] " + str);
	}
}
