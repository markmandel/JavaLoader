/**
 * 
 */
package com.compoundtheory.coldfusion.cfc.spring.config;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanCreationException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.config.InstantiationAwareBeanPostProcessorAdapter;

import com.compoundtheory.coldfusion.cfc.spring.ComponentProxyFactory;

/**
 * Post processor for switching out the ComponentProxyFactory for the CFC proxy it creates
 * 
 * @author Mark Mandel
 *
 */
public class ColdFusionPostProcessor extends InstantiationAwareBeanPostProcessorAdapter implements BeanFactoryAware
{
	private BeanFactory beanFactory;
	
	/**
	 * Constructor
	 */
	public ColdFusionPostProcessor()
	{
		super();
	}
	
	
	/* (non-Javadoc)
	 * @see org.springframework.beans.factory.config.InstantiationAwareBeanPostProcessorAdapter#postProcessBeforeInstantiation(java.lang.Class, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Object postProcessBeforeInstantiation(Class beanClass, String beanName) throws BeansException
	{
		if(!ComponentProxyFactory.class.isAssignableFrom(beanClass))
		{
			return null;
		}
		
		ComponentProxyFactory factory = (ComponentProxyFactory)getBeanFactory().getBean(beanName, ComponentProxyFactory.class);
		
		debug("Found: " + beanName);
		
		try
		{
			return factory.getProxy();
		}
		catch (Throwable e)
		{
			BeansException exc = new BeanCreationException(beanName, "Error creating CFC: " + factory.getPath(), e);
			
			throw exc;
		}
	}

	/* (non-Javadoc)
	 * @see org.springframework.beans.factory.config.InstantiationAwareBeanPostProcessorAdapter#predictBeanType(java.lang.Class, java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	@Override
	public Class predictBeanType(Class beanClass, String beanName)
	{
		//we have no idea at this point
		return null;
	}



	/* (non-Javadoc)
	 * @see org.springframework.beans.factory.BeanFactoryAware#setBeanFactory(org.springframework.beans.factory.BeanFactory)
	 */
	@Override
	public void setBeanFactory(BeanFactory beanFactory) throws BeansException
	{
		this.beanFactory = beanFactory;
	}

	private BeanFactory getBeanFactory()
	{
		return beanFactory;
	}
	
	private void debug(String str)
	{
		System.out.println("[" + getClass().getName() + "] " + str);
	}
}
