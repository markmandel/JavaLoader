package com.compoundtheory.coldfusion.cfc.spring.config;

import org.springframework.beans.factory.xml.NamespaceHandlerSupport;

/**
 * Namespace handler for the <coldfusion:> Spring XML namespace
 * 
 * @author Mark Mandel
 *
 */
public class ColdFusionNamespaceHandler extends NamespaceHandlerSupport
{

	/* (non-Javadoc)
	 * @see org.springframework.beans.factory.xml.NamespaceHandler#init()
	 */
	@Override
	public void init()
	{
		debug("INIT!v 0.2");
		
		registerBeanDefinitionParser("cfc", new ColdFusionBeanDefinitionParser());
	}
	
	private void debug(String str)
	{
		System.out.println("[" + getClass().getName() + "] " + str);
	}
}