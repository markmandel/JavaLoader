/**
 * 
 */
package com.compoundtheory.coldfusion.cfc.spring.config;

import org.springframework.beans.factory.config.ConstructorArgumentValues;
import org.springframework.beans.factory.support.AbstractBeanDefinition;
import org.springframework.beans.factory.support.GenericBeanDefinition;
import org.springframework.beans.factory.xml.AbstractBeanDefinitionParser;
import org.springframework.beans.factory.xml.ParserContext;
import org.springframework.scripting.config.LangNamespaceUtils;
import org.w3c.dom.Element;

import com.compoundtheory.coldfusion.cfc.spring.ColdFusionComponentFactory;

/**
 * Bean definition parser for the <coldfusion:> Spring namespace
 * 
 * @author Mark Mandel
 *
 */
public class ColdFusionBeanDefinitionParser extends AbstractBeanDefinitionParser
{
	
	private static final String SCRIPT_SOURCE_ATTRIBUTE = "script-source";
	private static final String SCRIPT_INTERFACES_ATTRIBUTE = "script-interfaces";
	
	/**
	 * Constructor
	 */
	public ColdFusionBeanDefinitionParser()
	{
		super();
	}

	/* (non-Javadoc)
	 * @see org.springframework.beans.factory.xml.AbstractBeanDefinitionParser#parseInternal(org.w3c.dom.Element, org.springframework.beans.factory.xml.ParserContext)
	 */
	@Override
	protected AbstractBeanDefinition parseInternal(Element element, ParserContext parserContext)
	{
		debug("parseInteneral: " + element.toString());
		
		//leverage the Scripting post processor
		LangNamespaceUtils.registerScriptFactoryPostProcessorIfNecessary(parserContext.getRegistry());
		
		//do a bean definition
		GenericBeanDefinition beanDef = new GenericBeanDefinition();
		
		beanDef.setSource(parserContext.extractSource(element));
		
		beanDef.setBeanClass(ColdFusionComponentFactory.class);
		
		ConstructorArgumentValues constructorArgs = beanDef.getConstructorArgumentValues();
		
		String scriptSource = element.getAttribute(SCRIPT_SOURCE_ATTRIBUTE);
		
		String[] interfaces = element.getAttribute(SCRIPT_INTERFACES_ATTRIBUTE).split(",");
		
		constructorArgs.addIndexedArgumentValue(0, scriptSource);
		constructorArgs.addIndexedArgumentValue(1, interfaces);
		
		return beanDef;
	}

	
	private void debug(String str)
	{
		System.out.println("[" + getClass().getName() + "] " + str);
	}
}
