/**
 * 
 */
package com.compoundtheory.coldfusion.cfc;

import java.io.File;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;
import java.lang.reflect.Proxy;

import coldfusion.filter.FusionContext;
import coldfusion.runtime.TemplateProxy;
import coldfusion.runtime.TemplateProxyFactory;;

/**
 * @author Mark Mandel
 *
 */
public class CFCDynamicProxy implements InvocationHandler
{
	private TemplateProxy cfc;
	
	private CFCDynamicProxy(TemplateProxy cfc)
	{
		setCFC(cfc);
	}
	
	private CFCDynamicProxy(String path) throws Throwable
	{
		TemplateProxy cfc = TemplateProxyFactory.resolveFile(FusionContext.getCurrent().pageContext, new File(path), null);
		
		setCFC(cfc);
	}
	
	public static Object createInstance(String path, Class<?>[] interfaces) throws Throwable
	{
		CFCDynamicProxy proxy = new CFCDynamicProxy(path);
		
		return createInstance(proxy, interfaces);
	}
	
	public static Object createInstance(TemplateProxy cfc, Class<?>[] interfaces)
	{
		CFCDynamicProxy proxy = new CFCDynamicProxy(cfc);
		
		return createInstance(proxy, interfaces);
	}
	
	private static Object createInstance(CFCDynamicProxy proxy, Class<?>[] interfaces)
	{
		return Proxy.newProxyInstance(proxy.getClass().getClassLoader(), interfaces, proxy);
	}
	
	/* (non-Javadoc)
	 * @see java.lang.reflect.InvocationHandler#invoke(java.lang.Object, java.lang.reflect.Method, java.lang.Object[])
	 */
	@Override
	public Object invoke(Object proxy, Method method, Object[] args) throws Throwable
	{
		if(args == null)
		{
			args = new Object[0];
		}
		
		return getCFC().invoke(method.getName(), args, FusionContext.getCurrent().pageContext);
	}

	private TemplateProxy getCFC()
	{
		return cfc;
	}

	private void setCFC(TemplateProxy cfc)
	{
		this.cfc = cfc;
	}
}
